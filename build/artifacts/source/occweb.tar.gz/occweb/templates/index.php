<?php
script('occweb', 'index');
script('occweb', 'term');
script('occweb', 'unix_formatting');
style('occweb', 'style');
?>

<div id="app" class="full-width">
<!--	<div id="app-navigation">-->
<!--		--><?php //print_unescaped($this->inc('navigation/index')); ?>
<!--		--><?php //print_unescaped($this->inc('settings/index')); ?>
<!--	</div>-->

	<div id="app-content" class="full-width">
	</div>
</div>

